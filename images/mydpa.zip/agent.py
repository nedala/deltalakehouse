from langchain.agents import create_spark_dataframe_agent
from langchain import OpenAI
from langchain.agents import create_pandas_dataframe_agent
from langchain.llms import OpenAI
import re
import json
import pandas as pd
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("SparkByExamples.com").getOrCreate()


def get_spark():
    return spark


API_KEY = "_key_"


def create_agent(df):
    # Create an OpenAI object.
    llm = OpenAI(openai_api_key=API_KEY, temperature=0)

    # Create a DataFrame agent.
    return create_spark_dataframe_agent(llm=OpenAI(temperature=0, openai_api_key=API_KEY), df=df, verbose=True)


def query_agent(agent, query):
    """
    Query an agent and return the response as a string.

    Args:
        agent: The agent to query.
        query: The query to ask the agent.

    Returns:
        The response from the agent as a string.
    """

    prompt = (
        """
            For a query, if it requires a table, reply as follows:
            {"table": {"columns": ["column1", "column2", ...], "data": [[value1, value2, ...], [value1, value2, ...], ...]}}

            If a query requires creating a bar chart, reply as follows:
            {"bar": {"columns": ["A", "B", "C", ...], "data": [25, 24, 10, ...]}}
            
            If a query requires creating a line chart, reply as follows:
            {"line": {"columns": ["A", "B", "C", ...], "data": [25, 24, 10, ...]}}
            
            If it is just asking a question that requires neither, reply as follows:
            {"answer": "answer"}
            
            If you do not know the answer, reply as follows:
            {"answer": "I do not know."}
            
            Import the JSON library. Return all chart, table, and answer output as a JSON string ideally readable by pandas library. The JSON should not cut out in the middle. 
            
            All strings in "columns" list and data list must be escaped with double quotes,
            
            For example: {"columns": ["title", "ratings_count"], "data": [["Gilead", 361], ["Spider's Web", 5164]]}
            
            Below query.
            
            """ + query
    )

    # Run the prompt through the agent.
    response = agent.run(prompt)

    # Convert the response to a string.
    return response.__str__()


def extract_json_dataframe(response):
    # Look for content surrounded by curly braces {}
    json_match = re.search(r'\{.*?\}', response, re.DOTALL | re.MULTILINE | re.IGNORECASE)

    if json_match:
        print(f"**********{json_match.group(0)}**********")
        json_str = json_match.group(0)
        try:
            return json.loads(json_str + "}")
        except ValueError as e:
            print(e)
            # Not a valid JSON or DataFrame format
            return json_str
    else:
        return response
