from agent import create_agent, query_agent, extract_json_dataframe, get_spark
import streamlit as st
import requests
import os, json
from sqlalchemy import create_engine, Table, Column, Integer, String, MetaData
import pandas as pd
st.set_page_config(layout="wide")
st.sidebar.title("Job Management UI")

agent = None
df = None
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []

tab = st.sidebar.radio(
    "Go to", ["Analytics IQ Assistant", "Job Configuration", "Dashboard",  "Database Management"])
if tab == "Analytics IQ Assistant":
    left_column, right_column = st.columns([8, 4])

    with right_column:
        st.write("#### Your dataset context")
        file_type = st.selectbox(
            "File Type", ["CSV", "TSV", "Excel", "JSON", "Parquet"])

        # If a filetype is selected, show the file uploader
        uploaded_file = st.file_uploader(
            "Upload your own file", type=[file_type])
        if uploaded_file:
            st.success(f"File {uploaded_file.name} uploaded successfully!")
            # Path where you want to store the temporary file
            temp_file_path = os.path.join("temp", uploaded_file.name)

            # Create a temporary directory if it doesn't exist
            if not os.path.exists("temp"):
                os.makedirs("temp")

            # Write the file's bytes to the disk
            with open(temp_file_path, "wb") as f:
                f.write(uploaded_file.getvalue())

            spark = get_spark()
            if file_type == "CSV":
                df = spark.read.csv(temp_file_path, header=True)
            elif file_type == "TSV":
                df = spark.read.csv(temp_file_path, sep='\t', header=True)
            elif file_type == "Excel":
                df = spark.createDataFrame(pd.read_excel(
                    temp_file_path, engine='openpyxl'))
            elif file_type == "JSON":
                df = spark.read.json(temp_file_path)
            elif file_type == "Parquet":
                df = spark.read.parquet(temp_file_path)
            # Display the first few rows of the dataframe
            st.write("## Preview")
            st.write(df.limit(5).toPandas())
            agent = create_agent(df)

    with left_column:
        st.write("#### Ask for Insights")

        # A simple interaction for the assistant, for demonstration
        user_input = st.text_input("Ask a data-related question:")
        if agent is not None and user_input:
            # Here, determine the type of response and its data
            # This is a mock example; you'll need to integrate your actual logic here
            response = user_input
            try:
                response = query_agent(agent, user_input)
            except Exception as e:
                response = f"Error: {e}"
            print(response)
            dict_response = extract_json_dataframe(response)
            if "bar" in dict_response:
                bot_response_type = "barchart"
                bot_response_data = pd.DataFrame(dict_response['bar']['data'], columns=dict_response['bar']['columns'])
            elif "line" in dict_response:
               bot_response_type = "linechart"
               bot_response_data = pd.DataFrame(dict_response['line']['data'], columns=dict_response['line']['columns'])
            elif "table" in dict_response:
                bot_response_type = "table"
                bot_response_data = pd.DataFrame(dict_response['table']['data'], columns=dict_response['table']['columns'])
            else:
                bot_response_type = "answer"
                bot_response_data = response

            # Check if the current interaction is different from the last stored interaction
            if not st.session_state.chat_history or st.session_state.chat_history[-1][:2] != (user_input, bot_response_type):
                st.session_state.chat_history.append(
                    (user_input, bot_response_type, bot_response_data))

                # Limit the chat history to a fixed number of entries
                if len(st.session_state.chat_history) > 5:  # for instance, 5 interactions
                    st.session_state.chat_history.pop(0)

                st.experimental_rerun()
        elif agent is None:
            st.write("**Assistant**: Upload a dataset to get started...")

        if st.session_state.chat_history:
            st.empty()
            st.markdown("""---""", unsafe_allow_html=True)
            st.write("#### Chat History")
            # Render chat history
            for interaction in st.session_state.chat_history[::-1]:
                user_question, bot_response_type, bot_response_data = interaction
                st.markdown(f"**You**: {user_question}")

                # Based on the bot_response_type, render the appropriate component
                if bot_response_type == "barchart":
                    st.markdown(f"**Assistant**:")
                    st.bar_chart(bot_response_data)
                elif bot_response_type == "linechart":
                    st.markdown(f"**Assistant**:")
                    st.line_chart(bot_response_data)
                elif bot_response_type == "table":
                    st.markdown(f"**Assistant**:")
                    st.table(bot_response_data)
                elif bot_response_type == "markdown":
                    st.markdown(f"**Assistant**: {bot_response_data}")
                else:
                    st.markdown(f"**Assistant**: {bot_response_data}")


elif tab == "Dashboard":
    pass
elif tab == "Job Configuration":
    left_column, _ = st.columns([11, 1])
    with left_column:
        st.write("#### Configure a new job")
        source_type = st.selectbox("Data Integration Source Type", ["Ad Hoc",
                                                                    "File", "Database", "S3 Landing", "Kafka", "Kinesis Stream", "Salesforce", "RingCentral"])
        # Dynamic options based on source type
        if source_type == "Ad Hoc":
            file_type = st.selectbox(
                "File Type", ["CSV", "TSV", "Excel", "JSON", "Parquet"])

            # If a filetype is selected, show the file uploader
            uploaded_file = st.file_uploader("Choose a file", type=[file_type])
            if uploaded_file:
                st.success(f"File {uploaded_file.name} uploaded successfully!")
                if file_type == "CSV":
                    df = pd.read_csv(uploaded_file, num_rows=5)
                elif file_type == "TSV":
                    df = pd.read_csv(uploaded_file, sep='\t', num_rows=5)
                elif file_type == "Excel":
                    df = pd.read_excel(
                        uploaded_file, engine='openpyxl', num_rows=5)
                elif file_type == "JSON":
                    df = pd.read_json(uploaded_file, num_rows=5)
                elif file_type == "Parquet":
                    df = pd.read_parquet(uploaded_file, num_rows=5)
                # Display the first few rows of the dataframe
                st.write("## Preview")
                st.write(df.head(5))

        elif source_type == "File":
            file_type = st.selectbox(
                "File Type", ["CSV", "TSV", "Excel", "JSON", "Parquet"])
            s3_endpoint = st.text_input("S3 Endpoint")
            s3_bucket = st.text_input("S3 Bucket")
            s3_path = st.text_input("S3 Object Path")
            accesskey = st.text_input("S3 Accesskey")
            secretkey = st.text_input("S3 Secretkey", type="password")
        elif source_type == "Database":
            database_type = st.selectbox(
                "Database", ["Teradata", "SQL Server", "DB2", "Oracle", "JDBC"])

            host = st.text_input("Host")
            port = st.text_input("Port")
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            source_db_name = st.text_input("Source Database Name")
            source_table_name = st.text_input("Source Table Name")

        # Embed custom CSS
        st.empty()
        st.markdown("""---""", unsafe_allow_html=True)
        with st.container():
            st.write("#### Destination Configuration")
            st.write("Provide details about the destination.")
            dest_db_name = st.text_input("Destination Database Name")
            table_name = st.text_input("Table Name")
            s3_location = st.text_input("S3 Location")

        st.empty()
        st.markdown("""---""", unsafe_allow_html=True)
        with st.container():
            st.markdown("""<div class="help-section">""",
                        unsafe_allow_html=True)
            st.write("##### Help Section")
            st.write(
                "Here are some tips and tricks to help you navigate through the application:")

            # List out your tips
            st.markdown(
                "- **Data Integration Source Type**: Choose the appropriate source for data. If 'file' is selected, upload options will appear.")
            st.markdown(
                "- **Destination Database Name**: Provide the name of the target database.")
            st.markdown(
                "- **S3 Location**: Only relevant if 's3 bucket' is chosen as source. Provide a valid S3 URI.")
            st.markdown(
                "- **Table Name**: Ensure this matches the database schema if you're integrating with a DB.")
            # Placeholder link, replace with actual documentation link if available.
            st.markdown(
                "- 🚀 For advanced configurations, check our [documentation](#).")
            st.markdown("""</div>""", unsafe_allow_html=True)
else:
    pass
