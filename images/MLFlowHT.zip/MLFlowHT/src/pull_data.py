import pandas as pd
from sqlalchemy import create_engine

# Set up the database connection
engine = create_engine('oracle+cx_oracle://username:password@hostname:port/service_name')

# Query to retrieve the data from the database table
query = "SELECT text_column FROM your_table"

# Read the data into a DataFrame using pandas and SQLAlchemy
df = pd.read_sql(query, con=engine)

# Close the database connection
engine.dispose()

# Print the DataFrame
print(df.head())
