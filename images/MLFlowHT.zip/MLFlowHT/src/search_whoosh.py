import pandas as pd
from whoosh.index import open_dir
from whoosh.qparser import QueryParser

def search_codes_whoosh(query_str, index_dir, n=10, scoring='BM25'):
    # Open the Whoosh index
    index = open_dir(index_dir)
    
    # Create a searcher for the index
    searcher = index.searcher()
    
    # Set up the query parser
    query_parser = QueryParser("description", schema=index.schema)
    
    # Parse the query
    query = query_parser.parse(query_str)
    
    # Perform the search and retrieve the top N results
    results = searcher.search(query, limit=n, scored=True, terms=True, filter=None, sortedby=scoring)
    
    # Extract the Code, Score, and Description from the results
    data = {
        'Code': [],
        'Score': [],
        'Description': []
    }
    
    for result in results:
        data['Code'].append(result['code'])
        data['Score'].append(result.score)
        data['Description'].append(result['description'])
    
    # Create a Pandas DataFrame from the extracted data
    df = pd.DataFrame(data)
    
    return df
