def evaluate_accuracy(validation_df, output_df):
    # Extract the known codes and predicted codes from the dataframes
    known_codes = validation_df['Code']
    predicted_codes = output_df['Code']
    
    # Initialize accuracy counters for each classification level
    accuracy_2_digit = 0
    accuracy_4_digit = 0
    accuracy_6_digit = 0
    
    # Iterate over the codes and calculate accuracy at each level
    for known_code, predicted_code in zip(known_codes, predicted_codes):
        # Get the substrings for each classification level
        known_2_digit = known_code[:2]
        known_4_digit = known_code[:4]
        known_6_digit = known_code[:6]
        
        predicted_2_digit = predicted_code[:2]
        predicted_4_digit = predicted_code[:4]
        predicted_6_digit = predicted_code[:6]
        
        # Compare the predicted code with the known code and update accuracy counters
        if predicted_2_digit == known_2_digit:
            accuracy_2_digit += 1
        
        if predicted_4_digit == known_4_digit:
            accuracy_4_digit += 1
        
        if predicted_6_digit == known_6_digit:
            accuracy_6_digit += 1
    
    # Calculate accuracy percentages
    total_samples = len(validation_df)
    accuracy_2_digit_pct = accuracy_2_digit / total_samples * 100
    accuracy_4_digit_pct = accuracy_4_digit / total_samples * 100
    accuracy_6_digit_pct = accuracy_6_digit / total_samples * 100
    
    # Create a summary dictionary of accuracy results
    accuracy_results = {
        'Accuracy @ 2-digit level': accuracy_2_digit_pct,
        'Accuracy @ 4-digit level': accuracy_4_digit_pct,
        'Accuracy @ 6-digit level': accuracy_6_digit_pct
    }
    
    return accuracy_results

# Assuming you have a validation_df and output_df
accuracy_results = evaluate_accuracy(validation_df, output_df)

# Print the accuracy results
for level, accuracy in accuracy_results.items():
    print(f"{level}: {accuracy:.2f}%")

import pandas as pd
from sklearn.metrics import accuracy_score

def evaluate_classifier(classifier, validation_df):
    # Make predictions using the classifier
    predictions = classifier.predict(validation_df)
    
    # Extract the known codes from the validation dataframe
    known_codes = validation_df['Code']
    
    # Calculate accuracy using the known codes and predicted codes
    accuracy = accuracy_score(known_codes, predictions)
    
    return accuracy

# Function to evaluate the committee classifier
def evaluate_committee_classifier(classifiers, validation_df):
    # Make predictions using each classifier
    predictions = []
    for classifier in classifiers:
        classifier_predictions = classifier.predict(validation_df)
        predictions.append(classifier_predictions)
    
    # Combine the predictions of each classifier using voting or other ensemble methods
    committee_predictions = ...  # Perform ensemble aggregation
    
    # Extract the known codes from the validation dataframe
    known_codes = validation_df['Code']
    
    # Calculate accuracy using the known codes and committee predictions
    accuracy = accuracy_score(known_codes, committee_predictions)
    
    return accuracy

# Usage example
validation_df = ...  # Load the validation dataframe

# Define the three classifiers
whoosh_classifier = WhooshClassifier(...)
embedding_classifier = EmbeddingClassifier(...)
custom_embedding_classifier = CustomEmbeddingClassifier(...)

# Evaluate each classifier
whoosh_accuracy = evaluate_classifier(whoosh_classifier, validation_df)
embedding_accuracy = evaluate_classifier(embedding_classifier, validation_df)
custom_embedding_accuracy = evaluate_classifier(custom_embedding_classifier, validation_df)

# Print the accuracy of each classifier
print("Whoosh Classifier Accuracy:", whoosh_accuracy)
print("Embedding Classifier Accuracy:", embedding_accuracy)
print("Custom Embedding Classifier Accuracy:", custom_embedding_accuracy)

# Combine the classifiers into a committee classifier
classifiers = [whoosh_classifier, embedding_classifier, custom_embedding_classifier]
committee_accuracy = evaluate_committee_classifier(classifiers, validation_df)

# Print the accuracy of the committee classifier
print("Committee Classifier Accuracy:", committee_accuracy)
