import ast
import atexit
import functools
import io
import itertools
import json
import os
import sys
import uuid
from datetime import datetime, timedelta

import findspark
import numpy as np
import pandas as pd

findspark.init()

import pyspark
from IPython.display import HTML, display
from pyspark.sql import DataFrame, Row, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.window import Window, WindowSpec


class SparkContextManager:
    def __enter__(self):
        self.spark = (
            SparkSession.builder.master("local[32,2]")
            .config("spark.driver.memory", "32g")
            .config("spark.jars.packages", "io.delta:delta-core_2.12:2.3.0")
            .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
            .config(
                "spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog",
            )
            .getOrCreate()
        )
        self.sc = self.spark.sparkContext
        self.sc.setLogLevel("ERROR")
        self.sc.addPyFile(f"{os.getcwd()}/whoosh_modules.py")

        def del_spark():
            try:
                if "spark" in vars(self):
                    self.spark.stop()
            except:
                pass
            finally:
                del self.spark

        atexit.register(del_spark)
        display(f"Spark is ready {self.spark}")

        def reg(spark_df, name=None):
            uniqsig = name or f"df_{str(uuid.uuid4()).replace('-', '')}"
            spark_df.createOrReplaceTempView(uniqsig)
            return uniqsig

        def show(spark_df, rows=5, title=""):
            if title:
                display(HTML(f"""<H3>{title}</H3>"""))
            display(
                spark_df.select(
                    *[F.col(col).cast(T.StringType()) for col in spark_df.columns]
                )
                .limit(rows)
                .toPandas()
            )

        DataFrame.reg = reg
        DataFrame.dshow = show

        return self.spark

    def __exit__(self, exc_type, exc_value, traceback):
        try:
            if "spark" in vars(self):
                self.spark.stop()
        except:
            pass
        finally:
            del self.spark