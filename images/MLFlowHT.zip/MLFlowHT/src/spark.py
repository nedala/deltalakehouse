from pyspark.ml import Pipeline
from pyspark.ml.feature import HashingTF, IDF, StringIndexer
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.sql import SparkSession

# Create a SparkSession
spark = SparkSession.builder \
    .appName("TextClassifier") \
    .getOrCreate()

# Load your labeled samples for each class into a DataFrame
labeled_samples = spark.createDataFrame([
    ('sample text 1', 'Class A'),
    ('sample text 2', 'Class B'),
    ('sample text 3', 'Class C')
], ['Text', 'Class'])

# Create a StringIndexer to convert the class labels to numeric indices
indexer = StringIndexer(inputCol="Class", outputCol="Label")

# Create a feature transformation pipeline
pipeline = Pipeline(stages=[
    indexer,
    HashingTF(inputCol="Text", outputCol="rawFeatures", numFeatures=1000),
    IDF(inputCol="rawFeatures", outputCol="features"),
    RandomForestClassifier(labelCol="Label", featuresCol="features", numTrees=100)
])

# Split the data into training and validation sets
train_data, val_data = labeled_samples.randomSplit([0.8, 0.2], seed=42)

# Train the classifier
model = pipeline.fit(train_data)

# Make predictions on the validation set
predictions = model.transform(val_data)

# Select the predicted labels and ground truth labels for evaluation
evaluator = MulticlassClassificationEvaluator(labelCol="Label", predictionCol="prediction", metricName="accuracy")
accuracy = evaluator.evaluate(predictions)

print("Accuracy:", accuracy)

# Stop the SparkSession
spark.stop()
