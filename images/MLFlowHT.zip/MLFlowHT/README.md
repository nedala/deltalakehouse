# HTS Classifier MLFlow Experiment/Model

This repository contains code and resources for developing a simple HTS (Harmonized Tariff Schedule) classifier using MLFlow. The classifier is trained on raw language descriptions of HTS chapters and can be used to predict the HTS category of new instances.

## Project Structure

The repository is organized as follows:

- **data/**: This directory contains the preclassified instances of HTS description text that will be used for leaderboard selection and testing. It also includes the raw language descriptions of HTS chapters for training.

- **models/**: This directory will store the trained models generated during the MLFlow experiments.

- **src/**: This directory contains the source code for the HTS classifier.

    - **data_preparation.py**: This script handles the preprocessing and preparation of the training and test data.
    
    - **model_training.py**: This script defines the MLFlow experiment and performs the training of the HTS classifier model.
    
    - **model_evaluation.py**: This script evaluates the trained model on the test data and generates performance metrics and predictions.
    
    - **utils.py**: This module contains utility functions used throughout the project.
    
- **mlflow_server.py**: This script sets up an MLFlow server to track and manage the experiments and models.

- **requirements.txt**: This file lists the required dependencies for running the code.

## Getting Started

To get started with the HTS classifier, follow these steps:

1. Clone this repository to your local machine:

```
git clone <repository_url>
```

2. Install the required dependencies by running the following command in the project root directory:

```
pip install -r requirements.txt
```

3. Prepare the data by running the data preparation script:

```
python src/data_preparation.py
```

4. Train the HTS classifier model using MLFlow:

```
python src/model_training.py
```

5. Evaluate the trained model on the test data:

```
python src/model_evaluation.py
```

## MLFlow Tracking

The MLFlow tracking server is set up to log all experiments, parameters, metrics, and artifacts generated during the training process. You can access the MLFlow UI by running the following command:

```
python mlflow_server.py
```

Once the server is running, you can access the MLFlow UI by visiting `http://localhost:5000` in your web browser.

## Contributing

Contributions to this HTS classifier project are welcome. If you find any issues or have suggestions for improvement, please open an issue or submit a pull request.

## License

This project is licensed under the [MIT License](LICENSE).

---

Feel free to customize the README.md based on your specific project requirements and add any additional information or sections you deem necessary.