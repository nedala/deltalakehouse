import streamlit as st
import sqlite3
import requests
import os
import shutil
from pathlib import Path
import pandas as pd

conn = sqlite3.connect("/db/session.db")
c = conn.cursor()

# Create tables
c.execute(
    """
          CREATE TABLE IF NOT EXISTS sessions  
          (id INTEGER PRIMARY KEY, name TEXT,  
           model TEXT, prompt TEXT)
         """
)

c.execute(
    """
          CREATE TABLE IF NOT EXISTS messages
          (id INTEGER PRIMARY KEY, session_id INTEGER,
           role TEXT, message TEXT, prompt TEXT, temperature REAL, model TEXT,
           FOREIGN KEY(session_id) REFERENCES sessions(id))
         """
)

conn.commit()


# Streamlit app
st.set_page_config(layout="wide")

# Read the OLLAMA API endpoint from an environment variable
ollama_endpoint = os.getenv("OLLAMA_HOST", "http://localhost:11434")


# Function to ping the OLLAMA API and retrieve models
def get_ollama_models(endpoint):
    try:
        response = requests.get(f"{endpoint}/api/tags")
        if response.status_code == 200:
            models = response.json()
            return [model["name"] for model in models["models"]]
    except requests.exceptions.RequestException as e:
        st.write(f"Error connecting to OLLAMA API: {e}")
    return []


models = get_ollama_models(ollama_endpoint)
if models:
    st.sidebar.success("OLLAMA is available")
else:
    st.sidebar.error("OLLAMA is not available")


class Session:
    def __init__(self, id, name, model, prompt):
        self.id = id
        self.name = name
        self.model = model
        self.prompt = prompt


# Initialize the active session ID to None
active_session_id = None


def get_sessions():
    c.execute("SELECT * FROM sessions ORDER BY id DESC")
    return [Session(*row) for row in c.fetchall()]


def get_session_by_id(id):
    c.execute("SELECT * FROM sessions WHERE id=?", (id,))
    row = c.fetchone()
    return Session(*row) if row else None


def get_session_by_name(name):
    c.execute("SELECT * FROM sessions WHERE name=?", (name,))
    row = c.fetchone()
    return Session(*row) if row else None


def get_messages(session_id):
    c.execute("SELECT * FROM messages WHERE session_id=?", (session_id,))
    return c.fetchall()


def get_session():
    c.execute("SELECT * FROM sessions ORDER BY id DESC LIMIT 1")
    row = c.fetchone()
    return Session(*row) if row else None


def get_messages(session_id):
    c.execute("SELECT * FROM messages WHERE session_id=? ORDER BY id", (session_id,))
    return c.fetchall()


def delete_session(ids):
    for id in ids:
        c.execute("DELETE FROM sessions WHERE id=?", (id,))
    conn.commit()
    try:
        shutil.rmtree(f"sessions/{id}")
    except:
        pass


def get_history(session_id):
    q = """SELECT * FROM messages 
           JOIN sessions ON sessions.id = messages.session_id 
           WHERE session_id = ?
           ORDER BY messages.id"""
    c.execute(q, (session_id,))
    return c.fetchall()


def add_session(name, model, prompt):
    c.execute(
        "INSERT INTO sessions (name, model, prompt) VALUES (?, ?, ?)",
        (name, model, prompt),
    )
    session_id = c.lastrowid

    conn.commit()

    return get_session_by_id(session_id)


# Retrieve the latest session ID if available
latest_session_id = get_session()

# Sidebar
st.sidebar.header("Manage Sessions")

tab1, tab2 = st.sidebar.tabs(["Choose Session", "New Session"])
current_sessions = tab1.empty()
name_holder = tab2.empty()
model_holder = tab2.empty()
prompt_holder = tab2.empty()

with tab1:
    id = current_sessions.selectbox(
        "Choose Session", [session.name for session in get_sessions()]
    )
    latest_session_id = get_session_by_name(id)
    if latest_session_id:
        if tab1.button("Delete Session"):
            delete_session([latest_session_id.id])
            tab1.info("Session deleted")
            latest_session_id = get_session()
            name = name_holder.text_input(
                "Name",
                value=f"{latest_session_id.name}" if latest_session_id else None,
                key=f"name_{abs(hash(latest_session_id))}",
            )
            model = model_holder.selectbox(
                "Model",
                models,
                index=models.index(latest_session_id.model) if latest_session_id else 0,
                key=f"model_{abs(hash(latest_session_id))}",
            )
            prompt = prompt_holder.text_area(
                "Default Prompt",
                value=f"{latest_session_id.prompt}" if latest_session_id else None,
                key=f"prompt_{abs(hash(latest_session_id))}",
            )
            id = current_sessions.selectbox(
                "Choose Session", [session.name for session in get_sessions()]
            )

    if latest_session_id:
        tab1.header("File Upload")
        session_folder = f"sessions/{latest_session_id.id}"
        os.makedirs(session_folder, exist_ok=True)
        uploaded_file = tab1.file_uploader(
            "Upload:",
            type=["pdf", "csv", "txt", "xlsx", "docx"],
            key=f"file_upload_{abs(hash(session_folder))}",
            accept_multiple_files=True,
        )
        for file in uploaded_file:
            print("File name:", file.name)
            save_path = os.path.join(session_folder, file.name)
            print("Saving file to", save_path)
            if not os.path.exists(save_path):
                with open(save_path, "wb") as f:
                    f.write(file.read())
        if uploaded_file:
            tab1.info("Files saved successfully!")
        files = os.listdir(session_folder)
        if files:
            df = pd.DataFrame(files, columns=["Filename"])

            def delete_file(filename):
                print("Removing file", filename)
                os.remove(os.path.join(session_folder, filename))
                # Remove row from DF
                df.drop(df[df.Filename == filename].index, inplace=True)

            if not df.empty:
                selected = tab1.multiselect(
                    "Delete:", df.Filename.tolist(), df.Filename.tolist()
                )
                for file in df.Filename:
                    if file not in selected:
                        delete_file(file)

with tab2:
    name = name_holder.text_input(
        "Name",
        value=f"{latest_session_id.name}" if latest_session_id else None,
        key=f"name1_{abs(hash(latest_session_id))}",
    )
    model = model_holder.selectbox(
        "Model",
        models,
        index=models.index(latest_session_id.model) if latest_session_id else 0,
        key=f"model1_{abs(hash(latest_session_id))}",
    )
    prompt = prompt_holder.text_area(
        "Prompt",
        value=f"{latest_session_id.prompt}" if latest_session_id else None,
        key=f"prompt1_{abs(hash(latest_session_id))}",
    )
    if st.button("Create Session"):
        latest_session_id = add_session(name, model, prompt)
        tab2.info(f"Created session {name} with ID {latest_session_id.id}")
        id = current_sessions.selectbox(
            "Choose Session", [session.name for session in get_sessions()]
        )

# Set the default active session to the latest session if available
active_session_id = latest_session_id if latest_session_id else None


def return_ollama_llm(base_url=ollama_endpoint, repeat_penalty=1.3, temperature=0.1):
    from langchain.llms import Ollama
    from langchain.callbacks.manager import CallbackManager
    from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler

    if not hasattr(return_ollama_llm, "ollama"):
        return_ollama_llm.ollama = Ollama(
            model="llama2:13b",
            base_url=ollama_endpoint,
            repeat_penalty=repeat_penalty,
            temperature=temperature,
            callback_manager=CallbackManager([StreamingStdOutCallbackHandler()]),
        )
    return return_ollama_llm.ollama


def chain_prompt(interpreter_prompt, coder_prompt, explainer_prompt, description):
    from langchain.prompts import PromptTemplate
    from langchain.schema.runnable import RunnablePassthrough
    from langchain.schema import StrOutputParser

    interpret_prompt = PromptTemplate.from_template(interpreter_prompt)
    code_prompt = PromptTemplate.from_template(coder_prompt)
    explain_prompt = PromptTemplate.from_template(explainer_prompt)
    llm = return_ollama_llm
    interpret_chain = interpret_prompt | llm | StrOutputParser()
    code_chain = code_prompt | llm | StrOutputParser()
    explain_chain = explain_prompt | llm | StrOutputParser()
    chain = (
        {"better_description": interpret_chain}
        | RunnablePassthrough.assign(
            better_description=lambda x: x
        )
        | {"code": code_chain}
        | RunnablePassthrough.assign(description=lambda x: description)
        | RunnablePassthrough.assign(explanation=explain_chain)
    )
    return chain.invoke({"description": description})


if active_session_id is not None:
    session = active_session_id
    chat_window, side_window = st.columns([3, 1])
    with chat_window:
        from langchain.llms import Ollama
        from langchain.callbacks.manager import CallbackManager
        from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler

        interpretation_prompt = st.text_area(
            "Code Prompt",
            """You are a cargo inspector -- who from a short description of a product -- will interpret its intended use and describe the product better in short (30 words or less).\n\nProduct Description: {description}\n\Better description: """,
        )
        code_prompt = st.text_area(
            "Code Prompt",
            """You are a cargo inspector that will accurately and briefly predict the HTS classification code for a given description. You will only respond with the HTS code -- 10 digit code -- nothing more, nothing less.\n\nDescription: "{better_description}"\n\10 digit HTS Code: """,
        )
        explain_prompt = st.text_area(
            "Explain Prompt",
            """You are a cargo inspector that will succintly *explain* why you would categorize a cargo described as "{description}" with the HTS code of "{code}"? Provide simple, direct, brief, validated, and *factual* explanation of why the corresponding section, chapter, subchapter best explains the 10 digit HTS code. Supply the hierarchic match structure. \n\nExplanation: """,
        )
        description = st.text_input("Description", "Drones for farming")
        if st.button("Send Message"):
            st.markdown(
                f"""```json\n{chain_prompt(interpretation_prompt, code_prompt, explain_prompt, description)}\n```"""
            )
    with side_window:
        pass

# # File Upload
# st.header("File Upload")
# uploaded_file = st.sidebar.file_uploader(
#     "Upload a File:", type=["pdf", "csv", "txt", "xlsx", "docx"]
# )
# if uploaded_file:
#     st.sidebar.write("File Uploaded Successfully!")

# You can add code here to parse and analyze the uploaded file
# For example, you can use libraries like pandas for CSV and Excel files, PyPDF2 for PDFs, etc.
