import pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Installer") \
    .getOrCreate()

from delta.tables import *
exit(0)