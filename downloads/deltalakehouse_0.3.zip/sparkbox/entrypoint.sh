#!/bin/bash
set -e
mc config host add minio ${MINIO_HOST} ${MINIO_ACCESS_KEY} ${MINIO_SECRET_KEY} && \
mc alias set minio ${MINIO_HOST} ${MINIO_ACCESS_KEY} ${MINIO_SECRET_KEY} --api S3v4 && \
sleep 10 && \
mc mb -p minio/spark && \
mc mb -p minio/hdfs
sleep 10

until nc -zv -w 60 ${DB_HOST} 3306
do
  echo "Waiting for database connection..."
  sleep 5
done

if [[ -v DEPLOY_AIRFLOW ]]; then
    airflow db init && airflow users create -r Admin -u admin -p admin -e admin@localhost -f Admin -l Airflow
    mkdir -p ${AIRFLOW_HOME}/dags
    airflow scheduler &
    airflow webserver &
fi

schematool --initSchema --dbType mysql || true
start-metastore &
if [[ -v DEPLOY_THRIFT ]]; then
    ${SPARK_HOME}/sbin/start-thriftserver.sh --master=local[1] --driver-memory=1g \
    --hiveconf hive.server2.thrift.bind.host=0.0.0.0 \
    --hiveconf hive.server2.thrift.port=10000 \
    --hiveconf hive.server2.authentication=NOSASL \
    ${DELTA_EXT}
fi
SHELL=bash jupyter lab --port 8888 --no-browser --ip=* --NotebookApp.token='' --NotebookApp.password='' --allow-root &
tail -f /dev/null
